package pe.com.dao;

public interface ISolicitanteDao {

}
