package pe.com.dao;

public interface IInformeCompraDao {

}
