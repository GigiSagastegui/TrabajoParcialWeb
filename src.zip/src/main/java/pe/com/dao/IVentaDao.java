package pe.com.dao;

public interface IVentaDao {

}
