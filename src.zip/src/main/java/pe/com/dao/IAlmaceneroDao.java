package pe.com.dao;

public interface IAlmaceneroDao {

}
